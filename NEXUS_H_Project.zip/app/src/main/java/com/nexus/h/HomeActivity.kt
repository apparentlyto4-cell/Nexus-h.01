package com.nexus.h

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView

/** Optional NEXUS._H launcher: home screen + app drawer without hidden apps + gesture entry. */
class HomeActivity : Activity() {
    private lateinit var frame: GestureFrame
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private var apps: List<AppEntry> = emptyList()
    private var query = ""
    private var drawerOpen = false
    private var lastTrigger = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        frame = GestureFrame(this)
        frame.setBackgroundColor(Color.parseColor("#55000000"))
        frame.recognizer = GestureRecognizer(this) { g ->
            if (!drawerOpen && Credentials.isSet(this) && g == Store.gesture(this)) frame.post { openHidden() }
        }
        buildHome()
        buildDrawer()
        setContentView(frame)

        val fling = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (!drawerOpen && vy < -1800 && b.pointerCount == 1) { openDrawer(); return true }
                return false
            }
        })
        homeLayer.setOnTouchListener { _, e -> fling.onTouchEvent(e); false }
    }

    private lateinit var homeLayer: LinearLayout

    private fun buildHome() {
        homeLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(60), dp(20), dp(24))
            isClickable = true
        }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 64f)
            setTextColor(Palette.text)
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            setShadowLayer(8f, 0f, 2f, Color.parseColor("#88000000"))
            isClickable = true
            // Re-entry path: long-press the clock to open NEXUS._H (works even when its icon is hidden).
            setOnLongClickListener {
                startActivity(Intent(this@HomeActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            }
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, MMM d"; format24Hour = "EEEE, MMM d"
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Palette.sub)
        }
        homeLayer.add(clock, WRAP, WRAP)
        homeLayer.add(date, WRAP, WRAP, mb = 6)
        homeLayer.add(View(this), MATCH, 0, 1f)

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(26, Color.parseColor("#66101020"))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        homeLayer.add(dock, MATCH, WRAP, mb = 10)
        val openApps = ghostBtn("All apps") { openDrawer() }
        homeLayer.add(openApps, MATCH, WRAP)
        frame.addView(homeLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F00A0818"))
            setPadding(dp(14), dp(40), dp(14), dp(14))
            visibility = View.GONE
            isClickable = true
        }
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Palette.sub)
            setTextColor(Palette.text)
            background = glass(14)
            setPadding(dp(14), 0, dp(14), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: Editable?) { query = e?.toString()?.trim()?.lowercase() ?: ""; renderDrawer() }
            })
        }
        drawer.add(search, MATCH, dp(48), mb = 8)
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        grid = GridLayout(this).apply { columnCount = 4 }
        sv.addView(grid)
        drawer.add(sv, MATCH, 0, 1f)
        frame.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    override fun onResume() {
        super.onResume()
        Session.lock()
        loadApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
    }

    private fun loadApps() {
        val app = applicationContext
        Bg.executor.execute {
            val r = try { AppRepo.loadAll(app) } catch (t: Throwable) { emptyList() }
            Bg.main.post {
                if (isDestroyed || isFinishing) return@post
                apps = r
                renderDock(); renderDrawer()
            }
        }
    }

    private fun visibleApps(): List<AppEntry> {
        val hidden = Store.hidden(this)
        val hideSelf = Store.hideSelf(this)
        return apps.filter { !hidden.contains(it.key) && !(hideSelf && it.pkg == packageName) }
    }

    private fun renderDock() {
        dock.removeAllViews()
        val vis = visibleApps().associateBy { it.key }
        val pinned = Store.dock(this).mapNotNull { vis[it] }.take(5)
        if (pinned.isEmpty()) {
            dock.addView(tv("Long-press an app in All apps to pin it here", 13f, Palette.sub).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) },
                LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }
        for (e in pinned) {
            val t = appTile(e)
            t.setOnClickListener { launch(e) }
            t.setOnLongClickListener { appMenu(e); true }
            dock.add(t, 0, WRAP, 1f)
        }
    }

    private fun renderDrawer() {
        grid.removeAllViews()
        val list = visibleApps().filter { query.isEmpty() || it.label.lowercase().contains(query) }
        for (e in list) {
            val t = appTile(e)
            t.setOnClickListener { launch(e) }
            t.setOnLongClickListener { appMenu(e); true }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, GridLayout.FILL, 1f)
            ).apply { width = 0; height = WRAP }
            grid.addView(t, lp)
        }
    }

    private fun launch(e: AppEntry) {
        if (e.pkg == packageName) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else if (!AppRepo.launch(this, e)) toast("Could not open ${e.label}.")
        if (drawerOpen) closeDrawer()
    }

    private fun appMenu(e: AppEntry) {
        val pinned = Store.dock(this).contains(e.key)
        val items = arrayOf(if (pinned) "Unpin from dock" else "Pin to dock", "App info")
        AlertDialog.Builder(this).setTitle(e.label).setItems(items) { _, which ->
            if (which == 0) {
                val d = Store.dock(this).toMutableList()
                if (pinned) d.remove(e.key) else if (d.size < 5) d.add(e.key) else toast("The dock holds up to 5 apps.")
                Store.setDock(this, d); renderDock()
            } else AppRepo.openAppInfo(this, e.pkg)
        }.show()
    }

    private fun openDrawer() {
        drawerOpen = true
        search.setText("")
        renderDrawer()
        drawer.alpha = 0f
        drawer.translationY = dp(60).toFloat()
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).translationY(0f).setDuration(180).start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        drawer.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(150).withEndAction { drawer.visibility = View.GONE }.start()
    }

    private fun openHidden() {
        val now = System.currentTimeMillis()
        if (now - lastTrigger < 1200) return
        lastTrigger = now
        Session.lock()
        startActivity(Intent(this, HiddenAppsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
        // A launcher stays on screen when Back is pressed.
    }
}
