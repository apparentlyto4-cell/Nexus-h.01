package com.nexus.h

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager

/**
 * Base for every screen that must only be visible after the user's lock was verified.
 * Content is built only after unlocking; it is hidden again whenever the session locks.
 */
abstract class SecureActivity : Activity() {
    private var authPending = false
    private var built = false
    private val REQ_AUTH = 7001

    abstract fun buildUi()
    open fun onSecureResume() {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        if (!Credentials.isSet(this)) { finish(); return }
        if (Session.unlocked) { buildUi(); built = true } else requestAuth()
    }

    override fun onResume() {
        super.onResume()
        if (authPending) return
        if (!Session.unlocked) { requestAuth(); return }
        Session.internalNav = false
        content().visibility = View.VISIBLE
        if (!built) { buildUi(); built = true } else onSecureResume()
    }

    override fun onPause() {
        super.onPause()
        if (!Session.internalNav && !isChangingConfigurations) Session.lock()
    }

    private fun content(): View = findViewById(android.R.id.content)

    private fun requestAuth() {
        if (authPending) return
        authPending = true
        if (built) content().visibility = View.INVISIBLE
        startActivityForResult(Intent(this, AuthActivity::class.java), REQ_AUTH)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_AUTH) {
            authPending = false
            if (resultCode == RESULT_OK && Session.unlocked) {
                Session.internalNav = false
                content().visibility = View.VISIBLE
                if (!built) { buildUi(); built = true } else onSecureResume()
            } else {
                finish()
            }
        }
    }

    /** Open another secure screen without re-locking. */
    fun startInternal(i: Intent) {
        Session.internalNav = true
        startActivity(i)
    }

    fun finishInternal() {
        Session.internalNav = true
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        Session.internalNav = !(this is HiddenAppsActivity)
        super.onBackPressed()
    }
}
