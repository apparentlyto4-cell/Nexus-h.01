package com.nexus.h

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : SecureActivity() {
    private lateinit var body: LinearLayout
    private val REQ_NOTIF = 31
    private val REQ_HOME = 32
    private var notifAsked = false

    override fun buildUi() {
        val s = Screen(this, "Settings")
        body = s.body
        setContentView(s.root)
        refresh()
    }

    override fun onSecureResume() { Launcher.selfHeal(this); refresh() }

    private fun section(title: String): LinearLayout {
        body.add(tv(title.uppercase(), 12f, Palette.purple, true), mt = 14, mb = 6, ml = 4)
        val c = card(14)
        body.add(c)
        return c
    }

    private fun refresh() {
        body.removeAllViews()
        val type = Credentials.type(this)
        val home = Perms.isDefaultHome(this)

        // ---- Security
        val sec = section("Security")
        sec.addView(navRow("Change lock type", "Currently: ${LockType.title(type)}") {
            startInternal(Intent(this, ChangeLockActivity::class.java))
        })
        sec.addView(divider())
        sec.addView(navRow("Change ${LockType.title(type)}", "Verify your current lock, then set a new one") {
            startInternal(Intent(this, ChangeLockActivity::class.java).putExtra("type", type))
        })
        sec.addView(divider())
        sec.addView(navRow("Open gesture", Store.gesture(this).title) { startInternal(Intent(this, GestureActivity::class.java)) })

        // ---- Hidden apps & App Lock
        val apps = section("Hidden apps & App Lock")
        apps.addView(navRow("Manage hidden apps", "${Store.hidden(this).size} hidden, ${Store.locked(this).size} locked") {
            startInternal(Intent(this, HiddenAppsActivity::class.java))
        })
        apps.addView(divider())
        apps.addView(switchRow("Enforce app locks", "Ask for your lock when a locked app is opened.", Store.lockEnforce(this)) {
            Store.setLockEnforce(this, it)
        })
        val acc = Perms.accessibilityEnabled(this)
        apps.add(
            tv(if (acc) "✓ Accessibility service is on — locks can be enforced." else "Accessibility is OFF — locks are not enforced yet.",
                13f, if (acc) Palette.ok else Palette.cyan, true), mt = 4
        )
        if (!acc) apps.add(ghostBtn("Turn on Accessibility") { Perms.openAccessibility(this) }, mt = 8)

        // ---- Launcher mode
        val lm = section("Launcher mode")
        lm.addView(tv(if (home) "✓ NEXUS._H is your Home app" else "Standard mode (NEXUS._H is a normal app)", 15f, if (home) Palette.ok else Palette.text, true))
        lm.add(
            tv(
                if (home) "Hidden apps are left out of the NEXUS._H home screen and app drawer. Your gesture works on the NEXUS._H home screen."
                else "Apps are hidden and locked inside NEXUS._H only. Your phone's own launcher still shows their icons. Choose NEXUS._H as your Home app to hide them from the app drawer and use gestures on the home screen.",
                13f, Palette.sub
            ), mt = 4
        )
        lm.add(ghostBtn(if (home) "Change Home app" else "Set NEXUS._H as Home app") { Perms.chooseHome(this, REQ_HOME) }, mt = 10)
        lm.addView(divider())
        lm.addView(switchRow(
            "Hide NEXUS._H's own icon", if (home) "Removes it from app lists. Re-open it by pressing Home and long-pressing the clock." else "Available only while NEXUS._H is your Home app, so you can never be locked out.",
            Launcher.isIconHidden(this), home || Launcher.isIconHidden(this)
        ) { on ->
            if (on) confirmHideSelf() else { Launcher.setIconHidden(this, false); Store.setHideSelf(this, false); toast("Icon restored") }
        })

        // ---- Quick exit
        val qe = section("Clean & Exit button")
        qe.addView(tv("Position on the Hidden apps screen", 14f, Palette.text, true))
        val names = listOf("Top-left", "Bottom-left", "Bottom-center", "Bottom-right")
        // two rows of two so labels never clip on small screens
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in names.indices) {
            val ch = chip(names[i], Store.qePos(this) == i) { Store.setQePos(this, i); refresh() }
            (if (i < 2) r1 else r2).add(ch, 0, WRAP, 1f, mr = if (i % 2 == 0) 8 else 0)
        }
        qe.add(r1, mt = 8); qe.add(r2, mt = 8)
        qe.addView(divider())
        qe.addView(switchRow("Floating button over other apps", "Optional. Needs “Display over other apps”. Appears after you open Hidden apps.", Store.floating(this)) { on ->
            if (on && !Perms.overlay(this)) { Store.setFloating(this, false); Perms.openOverlay(this); toast("Allow “Display over other apps”, then switch this on again."); refresh() }
            else { Store.setFloating(this, on); if (!on) QuickExitService.stop(this) }
        })
        val last = Store.lastClean(this).split("|")
        if (last.size == 2) {
            val kb = (last[1].toLongOrNull() ?: 0L) / 1024
            qe.add(tv("Last cleanup: removed $kb KB of NEXUS._H's own temporary files. Other apps' caches are never touched.", 12.5f, Palette.sub), mt = 6)
        } else {
            qe.add(tv("Clean & Exit clears only NEXUS._H's own temporary files, removes NEXUS._H from Recents and returns Home right away.", 12.5f, Palette.sub), mt = 6)
        }

        // ---- Permission status
        val ps = section("Permission status")
        for (p in permList(this)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.add(tv(p.title, 14f, Palette.text, true), 0, WRAP, 1f, mr = 8)
            top.addView(tv(if (p.granted) "✓ On" else "Needs attention", 13f, if (p.granted) Palette.ok else Palette.cyan, true))
            row.addView(top)
            row.add(tv(p.feature, 12.5f, Palette.sub), mt = 2)
            if (!p.granted) row.add(ghostBtn(p.actionLabel) { fix(p) }, mt = 8)
            ps.addView(row)
        }

        // ---- Help
        val help = section("Help")
        help.addView(navRow("Recovery & troubleshooting", "Forgot lock, missing icon, battery settings") {
            startActivity(Intent(this, RecoveryActivity::class.java))
        })
        help.addView(divider())
        help.add(tv("NEXUS._H has no Internet permission, no analytics and no accounts. Everything stays on this phone.", 12.5f, Palette.sub), mt = 6)
        body.add(tv("NEXUS._H 1.0.0", 12f, Palette.sub).apply { gravity = android.view.Gravity.CENTER }, mt = 18, mb = 8)
    }

    private fun fix(p: PermInfo) {
        when (p.id) {
            "accessibility" -> Perms.openAccessibility(this)
            "overlay" -> Perms.openOverlay(this)
            "notifications" -> {
                if (!notifAsked) { notifAsked = true; Perms.requestNotifications(this, REQ_NOTIF) }
                else Perms.openNotificationSettings(this)
            }
            "home" -> Perms.chooseHome(this, REQ_HOME)
        }
    }

    private fun confirmHideSelf() {
        AlertDialog.Builder(this).setTitle("Hide NEXUS._H's icon?")
            .setMessage("NEXUS._H will disappear from app lists. To open it again: press Home and long-press the clock. You can also pick NEXUS._H again under Settings → Default apps → Home app, or dial *#*#6394#*#*.\n\nIf NEXUS._H stops being your Home app, the icon comes back automatically.")
            .setPositiveButton("Hide icon") { _, _ ->
                Launcher.setIconHidden(this, true); Store.setHideSelf(this, true); toast("Icon hidden"); refresh()
            }
            .setNegativeButton("Cancel") { _, _ -> refresh() }
            .setOnCancelListener { refresh() }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) toast("Notifications are still off.")
            refresh()
        }
    }
}
