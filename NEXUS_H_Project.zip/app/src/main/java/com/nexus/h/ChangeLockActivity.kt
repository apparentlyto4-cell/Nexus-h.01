package com.nexus.h

import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

/** Verify old lock → (choose type) → create + confirm new lock → save atomically. */
class ChangeLockActivity : SecureActivity() {
    private lateinit var host: FrameLayout
    private var fixedType: String? = null

    override fun buildUi() {
        fixedType = intent.getStringExtra("type")
        val s = Screen(this, if (fixedType == null) "Change lock type" else "Change ${LockType.title(fixedType)}", scroll = false)
        host = FrameLayout(this)
        s.body.add(host, MATCH, 0, 1f)
        setContentView(s.root)
        stepVerify()
    }

    private fun show(v: View) {
        val sv = ScrollView(this).apply { isFillViewport = true }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(16))
        }
        box.add(v, MATCH, WRAP)
        sv.addView(box, FrameLayout.LayoutParams(MATCH, WRAP))
        host.removeAllViews()
        host.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun stepVerify() {
        show(LockScreenView(
            this, "Enter your current lock", "We need your current ${LockType.title(Credentials.type(this)).lowercase()} before making changes.",
            false, onVerified = { if (fixedType != null) stepCreate(fixedType!!) else stepChoose() }, onForgot = null
        ))
    }

    private fun stepChoose() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.add(tv("Choose a new lock type", 21f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 14)
        fun option(type: String, title: String, desc: String) {
            val box = card().apply { isClickable = true; setOnClickListener { stepCreate(type) }; pressable() }
            box.addView(tv(title + if (type == Credentials.type(this@ChangeLockActivity)) "  (current)" else "", 17f, Palette.text, true))
            box.add(tv(desc, 13f, Palette.sub), mt = 4)
            c.add(box, mb = 10)
        }
        option(LockType.PATTERN, "Pattern", "Connect at least 4 dots.")
        option(LockType.PIN, "PIN", "4 to 12 digits.")
        option(LockType.PASSWORD, "Password", "6 or more characters.")
        show(c)
    }

    private fun stepCreate(type: String) {
        show(LockCreateView(this, type) { secret ->
            Credentials.save(this, type, secret)
            toast("${LockType.title(type)} saved")
            finishInternal()
        })
    }
}
