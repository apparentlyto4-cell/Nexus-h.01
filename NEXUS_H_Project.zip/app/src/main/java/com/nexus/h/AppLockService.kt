package com.nexus.h

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Minimal app-lock enforcement. Only listens for window-state changes to learn the foreground
 * package name. It never reads screen content, never records input and never uses the network.
 */
class AppLockService : AccessibilityService() {
    private var lastPkg = ""
    private var lastLaunch = 0L
    private var imeCache: Set<String> = emptySet()
    private var imeAt = 0L

    private val ignored = setOf(
        "android", "com.android.systemui",
        "com.google.android.permissioncontroller", "com.android.permissioncontroller"
    )

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            AppLockState.allowedPkg = null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try { registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF)) } catch (_: Throwable) {}
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg in ignored) return
        if (!Store.lockEnforce(this)) return
        val locked = Store.lockedPackages(this)
        if (pkg !in locked && pkg in imePackages()) return

        val allowed = AppLockState.allowedPkg
        if (allowed != null && allowed != pkg) AppLockState.allowedPkg = null

        if (pkg in locked && AppLockState.allowedPkg != pkg) {
            val now = System.currentTimeMillis()
            // Anti-loop: do not relaunch while the lock screen is up or was just launched for this app.
            if (AppLockState.overlayShowing && now - lastLaunch < 4000) return
            if (pkg == lastPkg && now - lastLaunch < 1200) return
            lastPkg = pkg; lastLaunch = now
            try {
                startActivity(
                    Intent(this, AppLockActivity::class.java)
                        .putExtra("pkg", pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                )
            } catch (_: Throwable) {
            }
        }
    }

    private fun imePackages(): Set<String> {
        val now = System.currentTimeMillis()
        if (now - imeAt > 30_000) {
            imeAt = now
            imeCache = try {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .enabledInputMethodList.map { it.packageName }.toSet()
            } catch (_: Throwable) { emptySet() }
        }
        return imeCache
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(screenOff) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
