package com.nexus.h

import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AddAppsActivity : SecureActivity() {
    private lateinit var grid: GridLayout
    private lateinit var info: TextView
    private lateinit var addBtn: TextView
    private var all: List<AppEntry> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var query = ""
    private var lockNew = true

    override fun buildUi() {
        val s = Screen(this, "Add apps", scroll = false)
        val search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Palette.sub)
            setTextColor(Palette.text)
            background = glass(14)
            setPadding(dp(14), 0, dp(14), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: Editable?) { query = e?.toString()?.trim()?.lowercase() ?: ""; render() }
            })
        }
        s.body.add(search, MATCH, dp(48), mb = 8)
        info = tv("Loading apps…", 14f, Palette.sub).apply { gravity = Gravity.CENTER }
        s.body.add(info, mt = 8)
        val sv = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        grid = GridLayout(this).apply { columnCount = 4 }
        sv.addView(grid)
        s.body.add(sv, MATCH, 0, 1f)

        val bottom = card(12)
        bottom.addView(switchRow("Also lock these apps", "Ask for your lock when they are opened (needs Accessibility).", lockNew) { lockNew = it })
        addBtn = primaryBtn("Add apps") { save() }
        bottom.add(addBtn, mt = 6)
        s.body.add(bottom, mt = 8)
        setContentView(s.root)
        updateButton()

        Bg.executor.execute {
            val r = try { AppRepo.loadAll(applicationContext) } catch (t: Throwable) { null }
            Bg.main.post {
                if (isDestroyed || isFinishing) return@post
                if (r == null) {
                    info.text = "Could not list your apps. Your device may be limiting app visibility."
                    info.setTextColor(Palette.danger)
                } else { all = r; render() }
            }
        }
    }

    private fun render() {
        grid.removeAllViews()
        val hidden = Store.hidden(this)
        val list = all.filter { it.pkg != packageName && !hidden.contains(it.key) && (query.isEmpty() || it.label.lowercase().contains(query)) }
        info.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        if (list.isEmpty()) {
            info.setTextColor(Palette.sub)
            info.text = if (all.isEmpty()) "Loading apps…" else if (query.isNotEmpty()) "No apps match “$query”." else "Every available app is already hidden."
        }
        for (e in list) {
            val t = appTile(e, selected.contains(e.key))
            t.setOnClickListener {
                if (!selected.add(e.key)) selected.remove(e.key)
                render(); updateButton()
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, GridLayout.FILL, 1f)
            ).apply { width = 0; height = WRAP }
            grid.addView(t, lp)
        }
    }

    private fun updateButton() {
        addBtn.text = if (selected.isEmpty()) "Select apps to add" else "Add ${selected.size} app${if (selected.size == 1) "" else "s"}"
        addBtn.alpha = if (selected.isEmpty()) 0.5f else 1f
    }

    private fun save() {
        if (selected.isEmpty()) { toast("Tap the apps you want to add first."); return }
        Store.setHidden(this, Store.hidden(this) + selected)
        if (lockNew) Store.setLocked(this, Store.locked(this) + selected)
        toast("Added ${selected.size} app${if (selected.size == 1) "" else "s"}")
        if (lockNew && !Perms.accessibilityEnabled(this)) toast("Turn on Accessibility in Settings so locks are enforced.")
        finishInternal()
    }
}
