package com.nexus.h

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Backup re-entry: dial *#*#6394#*#* . Best effort — some devices block secret codes. */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try {
            c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
        }
    }
}
