package com.nexus.h

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.CycleInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Functional nine-dot pattern pad. Emits the pattern as a digit string, e.g. "01258". */
class PatternView(c: Context) : View(c) {
    var onPattern: ((String) -> Unit)? = null
    private val sel = ArrayList<Int>()
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = c.dp(5).toFloat()
        strokeCap = Paint.Cap.ROUND
    }
    private var fx = 0f
    private var fy = 0f
    private var active = false
    private var enabledInput = true
    private var mode = 0 // 0 normal, 1 error
    private var cell = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cell = minOf(w, h) / 3f
    }

    private fun cx(i: Int) = (i % 3 + 0.5f) * cell
    private fun cy(i: Int) = (i / 3 + 0.5f) * cell

    override fun onDraw(canvas: Canvas) {
        val col = if (mode == 1) Palette.danger else Palette.violet
        if (sel.isNotEmpty()) {
            linP.color = col
            for (i in 0 until sel.size - 1) canvas.drawLine(cx(sel[i]), cy(sel[i]), cx(sel[i + 1]), cy(sel[i + 1]), linP)
            if (active) canvas.drawLine(cx(sel.last()), cy(sel.last()), fx, fy, linP)
        }
        for (i in 0..8) {
            val s = sel.contains(i)
            if (s) {
                dotP.color = col
                dotP.alpha = 60
                canvas.drawCircle(cx(i), cy(i), cell * 0.27f, dotP)
                dotP.color = col
                dotP.alpha = 255
                canvas.drawCircle(cx(i), cy(i), context.dp(9).toFloat(), dotP)
            } else {
                dotP.color = Color.WHITE
                dotP.alpha = 110
                canvas.drawCircle(cx(i), cy(i), context.dp(6).toFloat(), dotP)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!enabledInput) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                sel.clear(); mode = 0; active = true
                track(e.x, e.y)
            }
            MotionEvent.ACTION_MOVE -> track(e.x, e.y)
            MotionEvent.ACTION_UP -> {
                active = false
                invalidate()
                if (sel.isNotEmpty()) onPattern?.invoke(sel.joinToString(""))
            }
            MotionEvent.ACTION_CANCEL -> { active = false; sel.clear(); invalidate() }
        }
        return true
    }

    private fun track(x: Float, y: Float) {
        fx = x; fy = y
        for (i in 0..8) {
            val dx = x - cx(i); val dy = y - cy(i)
            if (dx * dx + dy * dy <= (cell * 0.30f) * (cell * 0.30f) && !sel.contains(i)) { addDot(i); break }
        }
        invalidate()
    }

    private fun addDot(d: Int) {
        if (sel.isNotEmpty()) {
            val a = sel.last()
            val dr = d / 3 - a / 3
            val dc = d % 3 - a % 3
            if (dr % 2 == 0 && dc % 2 == 0 && (dr != 0 || dc != 0)) {
                val mid = ((a / 3 + d / 3) / 2) * 3 + (a % 3 + d % 3) / 2
                if (!sel.contains(mid)) sel.add(mid)
            }
        }
        sel.add(d)
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    fun showError() {
        mode = 1; invalidate()
        postDelayed({ reset() }, 700)
    }

    fun reset() { sel.clear(); mode = 0; active = false; invalidate() }
    fun setInputEnabled(b: Boolean) { enabledInput = b }
}

class PinPadView(c: Context) : LinearLayout(c) {
    var onSubmit: ((String) -> Unit)? = null
    var minLen = 4
    private val sb = StringBuilder()
    private val display = c.tv("", 28f, Palette.text, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.2f }
    private var enabledInput = true
    private val hintError = ""

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        add(display, MATCH, c.dp(44), mb = 4)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK")
        for (r in 0 until 4) {
            val row = LinearLayout(c).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
            for (k in 0 until 3) row.addView(key(keys[r * 3 + k]))
            add(row, WRAP, WRAP)
        }
        render()
    }

    private fun key(label: String): TextView {
        val ctx = context
        return ctx.tv(label, if (label.length > 1 && label != "⌫") 16f else 24f, Palette.text, true).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(ctx.dp(70), ctx.dp(62)).apply { setMargins(ctx.dp(7), ctx.dp(5), ctx.dp(7), ctx.dp(5)) }
            background = if (label == "OK") android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Palette.violet, Palette.violetDeep)
            ).apply { cornerRadius = ctx.dp(18).toFloat() } else ctx.glass(18)
            isClickable = true
            pressable()
            setOnClickListener { press(label) }
            if (label == "⌫") setOnLongClickListener { sb.setLength(0); render(); true }
        }
    }

    private fun press(k: String) {
        if (!enabledInput) return
        when (k) {
            "⌫" -> if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
            "OK" -> {
                if (sb.length < minLen) { showError(); return }
                onSubmit?.invoke(sb.toString())
                return
            }
            else -> if (sb.length < 12) sb.append(k)
        }
        render()
    }

    private fun render() {
        display.text = if (sb.isEmpty()) "" else "●".repeat(sb.length)
    }

    fun clear() { sb.setLength(0); render() }
    fun showError() {
        animate().translationX(0f).setDuration(0).start()
        val a = android.animation.ObjectAnimator.ofFloat(this, "translationX", 0f, 16f)
        a.duration = 350; a.interpolator = CycleInterpolator(3f); a.start()
        sb.setLength(0); render()
    }
    fun setInputEnabled(b: Boolean) { enabledInput = b }
}

class PasswordView(c: Context) : LinearLayout(c) {
    var onSubmit: ((String) -> Unit)? = null
    var minLen = 6
    private val et = EditText(c)
    private var shown = false
    private var enabledInput = true

    init {
        orientation = VERTICAL
        val field = LinearLayout(c).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = c.glass(16)
            setPadding(c.dp(14), 0, c.dp(6), 0)
        }
        et.apply {
            hint = "Enter password"
            setHintTextColor(Palette.sub)
            setTextColor(Palette.text)
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            importantForAutofill = IMPORTANT_FOR_AUTOFILL_NO
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine()
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false }
        }
        field.add(et, 0, c.dp(52), 1f)
        val toggle = c.tv("Show", 13f, Palette.purple, true).apply {
            gravity = Gravity.CENTER
            minWidth = c.dp(56)
            minHeight = c.dp(48)
            setOnClickListener {
                shown = !shown
                val sel = et.selectionStart
                et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                    (if (shown) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
                et.setSelection(maxOf(0, sel))
                text = if (shown) "Hide" else "Show"
            }
        }
        field.addView(toggle)
        add(field, MATCH, WRAP, mb = 14)
        add(c.primaryBtn("Continue") { submit() })
    }

    private fun submit() {
        if (!enabledInput) return
        val s = et.text.toString()
        if (s.length < minLen) { showError(); return }
        onSubmit?.invoke(s)
    }

    fun clear() { et.setText("") }
    fun showError() {
        val a = android.animation.ObjectAnimator.ofFloat(this, "translationX", 0f, 16f)
        a.duration = 350; a.interpolator = CycleInterpolator(3f); a.start()
    }
    fun setInputEnabled(b: Boolean) { enabledInput = b; et.isEnabled = b }
    fun focusInput() { et.requestFocus() }
}

/** One entry component for all three lock types. */
class LockInputView(c: Context, val type: String) : LinearLayout(c) {
    var onSubmit: ((String) -> Unit)? = null
    private val msg = c.tv("", 14f, Palette.sub).apply { gravity = Gravity.CENTER; minLines = 2 }
    private var pattern: PatternView? = null
    private var pin: PinPadView? = null
    private var pw: PasswordView? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        add(msg, MATCH, WRAP, mb = 10)
        when (type) {
            LockType.PATTERN -> {
                val pv = PatternView(c)
                pv.onPattern = { s ->
                    if (s.length < 4) { setMessage("Connect at least 4 dots.", true); pv.showError() }
                    else {
                        onSubmit?.invoke(s)
                        pv.postDelayed({ pv.reset() }, 350)
                    }
                }
                pattern = pv
                add(pv, c.dp(280), c.dp(280))
            }
            LockType.PIN -> {
                val p = PinPadView(c)
                p.onSubmit = { onSubmit?.invoke(it) }
                pin = p
                add(p, MATCH, WRAP)
            }
            else -> {
                val p = PasswordView(c)
                p.onSubmit = { onSubmit?.invoke(it) }
                pw = p
                add(p, MATCH, WRAP)
            }
        }
    }

    fun setMessage(s: String, error: Boolean = false) {
        msg.text = s
        msg.setTextColor(if (error) Palette.danger else Palette.sub)
    }

    fun showError(s: String) {
        setMessage(s, true)
        pattern?.showError(); pin?.showError(); pw?.showError()
        pw?.clear()
    }

    fun clear() { pattern?.reset(); pin?.clear(); pw?.clear() }

    fun setInputEnabled(b: Boolean) {
        pattern?.setInputEnabled(b); pin?.setInputEnabled(b); pw?.setInputEnabled(b)
        alpha = if (b) 1f else 0.4f
    }
}

/** Enter + confirm flow used when creating or changing a lock. */
class LockCreateView(c: Context, private val type: String, private val onCreated: (String) -> Unit) : LinearLayout(c) {
    private val what = when (type) {
        LockType.PATTERN -> "pattern"
        LockType.PIN -> "PIN"
        else -> "password"
    }
    private val title = c.tv("", 20f, Palette.text, true).apply { gravity = Gravity.CENTER }
    private val input = LockInputView(c, type)
    private var first: String? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        add(title, MATCH, WRAP, mb = 6)
        add(input, MATCH, WRAP)
        stepOne("")
        input.onSubmit = { s ->
            val f = first
            if (f == null) {
                first = s
                title.text = "Confirm your $what"
                input.clear()
                input.setMessage("Enter it once more to confirm.")
            } else if (f == s) {
                onCreated(s)
            } else {
                first = null
                input.clear()
                stepOne("They did not match. Please start again.")
            }
        }
    }

    private fun stepOne(note: String) {
        title.text = "Create your $what"
        input.setMessage(
            when {
                note.isNotEmpty() -> note
                type == LockType.PATTERN -> "Draw a pattern connecting at least 4 dots."
                type == LockType.PIN -> "Choose a PIN with at least 4 digits."
                else -> "Choose a password with at least 6 characters."
            }, note.isNotEmpty()
        )
    }
}

/**
 * Verification panel with lockout handling. Used by the main unlock screen,
 * the app-lock screen and the "verify old lock" step.
 */
class LockScreenView(
    c: Context,
    title: String,
    subtitle: String,
    showLogo: Boolean,
    private val onVerified: () -> Unit,
    private val onForgot: (() -> Unit)?
) : LinearLayout(c) {
    private val type = Credentials.type(c) ?: LockType.PIN
    private val input = LockInputView(c, type)
    private var timer: CountDownTimer? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        if (showLogo) add(c.circleLogo(72), WRAP, WRAP, mb = 14)
        add(c.tv(title, 22f, Palette.text, true).apply { gravity = Gravity.CENTER }, MATCH, WRAP, mb = 4)
        add(c.tv(subtitle, 14f, Palette.sub).apply { gravity = Gravity.CENTER }, MATCH, WRAP, mb = 14)
        add(input, MATCH, WRAP)
        if (onForgot != null) add(c.linkBtn("Forgot your lock?") { onForgot.invoke() }, WRAP, WRAP, mt = 8)
        input.onSubmit = { secret -> attempt(secret) }
        checkLockout()
        if (type == LockType.PATTERN) input.setMessage("Draw your pattern")
        else if (type == LockType.PIN) input.setMessage("Enter your PIN")
        else input.setMessage("Enter your password")
    }

    private fun attempt(secret: String) {
        if (Credentials.lockoutRemainingMs(context) > 0) { checkLockout(); return }
        if (Credentials.verify(context, secret)) {
            Credentials.resetFails(context)
            onVerified()
        } else {
            val wait = Credentials.registerFail(context)
            if (wait > 0) {
                input.clear()
                checkLockout()
            } else {
                val left = Credentials.failsLeftBeforeLockout(context)
                input.showError("Incorrect ${LockType.title(type)}. $left ${if (left == 1) "try" else "tries"} left before a short lockout.")
            }
        }
    }

    private fun checkLockout() {
        timer?.cancel()
        val ms = Credentials.lockoutRemainingMs(context)
        if (ms <= 0) { input.setInputEnabled(true); return }
        input.setInputEnabled(false)
        timer = object : CountDownTimer(ms, 1000) {
            override fun onTick(left: Long) {
                input.setMessage("Too many wrong attempts. Try again in ${(left + 999) / 1000}s.", true)
            }
            override fun onFinish() {
                input.setInputEnabled(true)
                input.setMessage("You can try again now.")
            }
        }.start()
    }

    override fun onDetachedFromWindow() {
        timer?.cancel()
        super.onDetachedFromWindow()
    }
}
