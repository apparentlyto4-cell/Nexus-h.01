package com.nexus.h

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

/** Dashboard. Not secret itself: every sensitive screen asks for the lock first. */
class MainActivity : Activity() {
    private lateinit var frame: GestureFrame
    private var lastTrigger = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        if (!Store.onboarded(this) || !Credentials.isSet(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }
        frame = GestureFrame(this)
        frame.recognizer = GestureRecognizer(this) { g ->
            if (g == Store.gesture(this)) frame.post { openHidden() }
        }
        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        if (!::frame.isInitialized) return
        Session.lock()
        Launcher.selfHeal(this)
        render()
    }

    private fun openHidden() {
        val now = System.currentTimeMillis()
        if (now - lastTrigger < 1200) return
        lastTrigger = now
        Session.lock()
        startActivity(Intent(this, HiddenAppsActivity::class.java))
    }

    private fun render() {
        frame.removeAllViews()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val sv = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        sv.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        root.add(sv, MATCH, MATCH)
        frame.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))

        body.add(circleLogo(104), WRAP, WRAP, mt = 12, mb = 12)
        body.add(tv("NEXUS._H", 28f, Palette.text, true).apply { gravity = Gravity.CENTER }, mb = 2)
        body.add(tv("Private. Offline. Yours.", 13.5f, Palette.sub).apply { gravity = Gravity.CENTER }, mb = 20)

        body.add(primaryBtn("Open Hidden Apps") { openHidden() }, mb = 10)
        body.add(ghostBtn("Settings") { Session.lock(); startActivity(Intent(this, SettingsActivity::class.java)) }, mb = 16)

        val home = Perms.isDefaultHome(this)
        val acc = Perms.accessibilityEnabled(this)
        val g = Store.gesture(this)
        val st = card()
        st.addView(tv("Status", 13f, Palette.purple, true))
        fun line(k: String, v: String, good: Boolean?) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(2)) }
            r.add(tv(k, 14f, Palette.sub), 0, WRAP, 1f)
            r.addView(tv(v, 14f, when (good) { true -> Palette.ok; false -> Palette.cyan; null -> Palette.text }, true))
            st.addView(r)
        }
        line("Lock", LockType.title(Credentials.type(this)), null)
        line("Mode", if (home) "NEXUS._H Launcher" else "Standard (in-app)", home)
        line("App lock", if (!Store.lockEnforce(this)) "Off" else if (acc) "Active" else "Needs Accessibility", acc && Store.lockEnforce(this))
        line("Gesture", g.title, null)
        body.add(st, mb = 12)

        val tip = card()
        tip.addView(tv("How to open Hidden Apps", 13f, Palette.purple, true))
        tip.add(
            tv(
                "Tap “Open Hidden Apps”, or perform your gesture (${g.title}) on this screen" +
                    (if (home) " or on your NEXUS._H home screen." else ". Gestures on your home screen only work when NEXUS._H is your Home app."),
                13.5f, Palette.sub
            ), mt = 4
        )
        body.add(tip, mb = 12)

        if (!home) body.add(ghostBtn("Use NEXUS._H as my Home app") { Perms.chooseHome(this, 21) }, mb = 10)
        body.add(linkBtn("Recovery & help") { startActivity(Intent(this, RecoveryActivity::class.java)) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (::frame.isInitialized) render()
    }
}
