package com.nexus.h

import android.app.Activity
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.UserHandle
import android.os.UserManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class AppEntry(
    val key: String,
    val pkg: String,
    val cls: String,
    val user: UserHandle?,
    val label: String,
    val icon: Drawable,
    val available: Boolean = true
)

object AppRepo {
    fun keyOf(pkg: String, cls: String, serial: Long) = "$pkg/$cls#$serial"

    /** All launchable apps (including work/clone profiles the system exposes to us). Call off the main thread. */
    fun loadAll(c: Context): List<AppEntry> {
        val la = c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val um = c.getSystemService(Context.USER_SERVICE) as UserManager
        val out = ArrayList<AppEntry>()
        for (u in la.profiles) {
            val serial = um.getSerialNumberForUser(u)
            for (info in la.getActivityList(null, u)) {
                val cn = info.componentName
                out.add(
                    AppEntry(
                        keyOf(cn.packageName, cn.className, serial), cn.packageName, cn.className, u,
                        info.label?.toString() ?: cn.packageName, info.getBadgedIcon(0)
                    )
                )
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    /** Placeholder for a saved key whose app is no longer available. */
    fun missing(key: String): AppEntry {
        val pkg = key.substringBefore('/')
        return AppEntry(key, pkg, "", null, pkg.substringAfterLast('.') + " (unavailable)", ColorDrawable(Color.parseColor("#33FFFFFF")), false)
    }

    fun launch(c: Context, e: AppEntry): Boolean {
        if (!e.available) return false
        try {
            val la = c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            la.startMainActivity(ComponentName(e.pkg, e.cls), e.user!!, null, null)
            return true
        } catch (_: Throwable) {
        }
        return try {
            val i = c.packageManager.getLaunchIntentForPackage(e.pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun openAppInfo(c: Context, pkg: String) {
        try {
            c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
        }
    }
}

/** One launcher-style tile: icon + label (+ optional check / lock badge). */
fun Context.appTile(e: AppEntry, checked: Boolean? = null, locked: Boolean = false, labelColor: Int = Palette.text): LinearLayout {
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(8), dp(2), dp(8))
        isClickable = true
        isFocusable = true
        pressable()
    }
    val frame = FrameLayout(this)
    val icon = roundedIcon(e.icon, 56)
    frame.addView(icon, FrameLayout.LayoutParams(dp(56), dp(56)))
    if (checked != null) {
        val badge = tv(if (checked) "✓" else "", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(if (checked) Palette.violet else Color.parseColor("#66000000"))
                setStroke(dp(2), if (checked) Palette.violet else Color.WHITE)
            }
        }
        frame.addView(badge, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.END or Gravity.TOP))
    }
    if (locked) {
        val lk = tv("🔒", 10f).apply {
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1A1730"))
            }
        }
        frame.addView(lk, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.END or Gravity.BOTTOM))
    }
    col.addView(frame, LinearLayout.LayoutParams(dp(56), dp(56)))
    val t: TextView = tv(e.label, 12f, labelColor).apply {
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
    col.add(t, MATCH, WRAP, mt = 6)
    return col
}

fun Context.plusTile(label: String): LinearLayout {
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(8), dp(2), dp(8))
        isClickable = true
        isFocusable = true
        pressable()
    }
    val box = FrameLayout(this).apply { background = glass(16, Color.parseColor("#44A78BFA")) }
    box.addView(IconView(this, "plus"), FrameLayout.LayoutParams(MATCH, MATCH))
    col.addView(box, LinearLayout.LayoutParams(dp(56), dp(56)))
    col.add(tv(label, 12f, Palette.text).apply { gravity = Gravity.CENTER }, MATCH, WRAP, mt = 6)
    return col
}

object Perms {
    fun accessibilityEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(c, AppLockService::class.java)
        return s.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
    }

    fun overlay(c: Context) = Settings.canDrawOverlays(c)

    fun notifications(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun isDefaultHome(c: Context): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val r = c.packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
        return r?.activityInfo?.packageName == c.packageName
    }

    fun safeStart(a: Activity, i: Intent, requestCode: Int = -1): Boolean = try {
        if (requestCode >= 0) a.startActivityForResult(i, requestCode) else a.startActivity(i)
        true
    } catch (e: ActivityNotFoundException) {
        a.toast("This setting is not available on your device.")
        false
    } catch (e: SecurityException) {
        a.toast("This setting could not be opened.")
        false
    }

    fun openAccessibility(a: Activity) {
        Session.internalNav = true
        safeStart(a, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun openOverlay(a: Activity) {
        Session.internalNav = true
        if (!safeStart(a, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))))
            safeStart(a, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}")))
    }

    fun requestNotifications(a: Activity, code: Int) {
        if (Build.VERSION.SDK_INT >= 33) a.requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), code)
    }

    fun openNotificationSettings(a: Activity) {
        Session.internalNav = true
        val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.packageName)
        safeStart(a, i)
    }

    /** Opens the system flow for choosing the Home app. Never loops: only called from a user tap. */
    fun chooseHome(a: Activity, requestCode: Int) {
        Session.internalNav = true
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = a.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), requestCode)
                    return
                }
            }
        } catch (_: Throwable) {
        }
        openHomeSettings(a)
    }

    fun openHomeSettings(a: Activity) {
        Session.internalNav = true
        if (!safeStart(a, Intent(Settings.ACTION_HOME_SETTINGS))) safeStart(a, Intent(Settings.ACTION_SETTINGS))
    }
}

class PermInfo(
    val id: String,
    val title: String,
    val why: String,
    val feature: String,
    val granted: Boolean,
    val optional: Boolean,
    val actionLabel: String
)

fun permList(c: Context): List<PermInfo> {
    val l = ArrayList<PermInfo>()
    l.add(
        PermInfo(
            "accessibility", "Accessibility service (App Lock)",
            "Lets NEXUS._H notice which app has just opened so it can ask for your lock first. It does not read your screen, record what you type, or send anything anywhere.",
            "Needed for: locking protected apps.", Perms.accessibilityEnabled(c), true, "Open Accessibility Settings"
        )
    )
    l.add(
        PermInfo(
            "overlay", "Display over other apps",
            "Lets the optional floating Quick Exit button appear on top of other apps.",
            "Needed for: the floating Quick Exit button only.", Perms.overlay(c), true, "Open Settings"
        )
    )
    if (Build.VERSION.SDK_INT >= 33) l.add(
        PermInfo(
            "notifications", "Notifications",
            "Android shows a small notification while the floating Quick Exit button is active.",
            "Needed for: the floating Quick Exit button only.", Perms.notifications(c), true, "Allow notifications"
        )
    )
    l.add(
        PermInfo(
            "home", "Default Home app (Launcher mode)",
            "Makes NEXUS._H your Home screen so hidden apps are truly absent from your app drawer, and enables gestures and hiding NEXUS._H's own icon.",
            "Needed for: Launcher mode.", Perms.isDefaultHome(c), true, "Choose Home app"
        )
    )
    return l
}
