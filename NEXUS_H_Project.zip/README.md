# NEXUS._H
Native Kotlin Android app (no third-party libraries, no INTERNET permission).
Build: `gradle :app:assembleDebug` (Gradle 8.7, JDK 17, AGP 8.5.2, compileSdk 34, minSdk 26).
Recovery: see Settings > Recovery & troubleshooting inside the app.
